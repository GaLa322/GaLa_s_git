./objects/main_3led.o: main_3led.c
