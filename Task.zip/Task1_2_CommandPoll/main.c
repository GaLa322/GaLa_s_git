/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务一 (2)：上位机发 '#' 暂停发送，发 '*' 继续发送
  *
  * 在任务一 (1) 的基础上扩展：
  *   - 每轮发送前用"超时极短"的阻塞接收探一下有没有新字符
  *   - 收到 '#'  -> g_send_enable = 0（暂停，LED 常亮）
  *   - 收到 '*'  -> g_send_enable = 1（继续，LED 闪烁）
  *
  * 注意：这里用的是"查询方式"实现收发共存。
  *       任务二 (1) 会用真正的"串口接收中断"重做同样的功能。
  ******************************************************************************
  */
#include "project_config.h"
#include "main.h"

/* 上位机命令轮询的接收超时(ms)，不能太大否则影响发送节奏 */
#define RX_POLL_TIMEOUT   1

/* ============================ 全局变量 ============================ */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;

uint8_t g_msg[]        = "hello windows！\r\n";
uint8_t g_rx_byte      = 0;      /* 接收缓冲 */
uint8_t g_send_enable  = 1;      /* 1 = 正在发送；0 = 已暂停 */
uint32_t g_rx_count    = 0;      /* 累计收到的字节数 */

/* ============================ 函数声明 ============================ */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void PollRxCommand(void);
static void LED_Blink(uint32_t period_ms);

/**
  * @brief  LED 闪烁一次（半个周期点亮、半个周期熄灭），总耗时 period_ms
  * @param  period_ms 一个完整闪烁周期的时长(ms)，也就是两次发送之间的间隔
  * @note   PC13 是低电平点亮，所以亮 = GPIO_PIN_RESET，灭 = GPIO_PIN_SET
  */
static void LED_Blink(uint32_t period_ms)
{
  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_RESET);   /* 点亮 */
  HAL_Delay(period_ms / 2);
  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_SET);     /* 熄灭 */
  HAL_Delay(period_ms - period_ms / 2);
}

/**
  * @brief  主函数
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART1_UART_Init();

  while (1)
  {
    /* 1. 先处理上位机命令（无论暂停还是发送都要收命令） */
    PollRxCommand();

    /* 2. 根据标志位决定是否继续发送 */
    if (g_send_enable)
    {
      HAL_UART_Transmit(&huart1, g_msg, sizeof(g_msg) - 1, HAL_MAX_DELAY);
      LED_Blink(SEND_DELAY_MS);                     /* 发送中：LED 按发送周期闪烁 */
    }
    else
    {
      /* 暂停：把 LED 熄灭并保持住。
       * PC13 低电平点亮：GPIO_PIN_SET(输出高) = 灭，GPIO_PIN_RESET(输出低) = 亮 */
      HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_SET);
      HAL_Delay(10);                                /* 小延时，让主循环不至于空转 */
    }
  }
}

/**
  * @brief  查询方式读取上位机命令
  *         用极短超时(1ms)接收 1 字节，没收到就立刻返回，不阻塞发送循环
  */
static void PollRxCommand(void)
{
  if (HAL_UART_Receive(&huart1, &g_rx_byte, 1, RX_POLL_TIMEOUT) == HAL_OK)
  {
    g_rx_count++;

    if (g_rx_byte == '#')
    {
      g_send_enable = 0;                 /* 暂停发送 */
    }
    else if (g_rx_byte == '*')
    {
      g_send_enable = 1;                 /* 继续发送 */
    }
    /* 其他字符忽略 */
  }
}

/**
  * @brief  系统时钟配置：HSE 8MHz -> PLL x9 -> 72MHz
  */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  USART1 初始化：115200 / 8 / 1 / 无校验
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = 115200;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  GPIO 初始化：板载 LED (PC13)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();

  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_SET);
  GPIO_InitStruct.Pin   = LED_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);
}

/**
  * @brief  错误处理
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);
    for (volatile uint32_t i = 0; i < 400000; i++) { }
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
