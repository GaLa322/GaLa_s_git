/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务二 (1)：用【串口接收中断】重做任务一 (2)
  */
#include "project_config.h"   /* 只为了拿 BAUDRATE（波特率），其余全部在本文件写死 */
#include "main.h"

#define SIM_MODE   1

#define SEND_INTERVAL_MS     500

/* LED 闪烁：每亮/灭持续多少毫秒（250 → 亮 0.25s + 灭 0.25s，一秒闪两次） */
#define LED_HALF_PERIOD_MS   250

#define TX_TIMEOUT_MS        100

#define PULSE_EVERY_N_SENDS  50

#define PULSE_GAP_MS         1000

/* ============================ 全局变量 ============================ */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;      

uint8_t  g_msg[]       = "hello windows！\r\n";   /* 要发送的数据 */
uint8_t  g_rx_byte     = 0;             /* 中断接收缓冲，一次 1 字节 */
uint8_t  g_send_enable = 1;             /* 1 = 发送中；0 = 已暂停 */
uint32_t g_send_count  = 0;             /* 已发送条数，用于任务三的脉冲标注 */

volatile uint32_t g_la_pc13 = 0;

/* 函数声明 */
#if (SIM_MODE == 0)
static void SystemClock_Config(void);
#endif
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void LED_Set(uint8_t on);
static void PC13_Write(uint8_t high);

static void PC13_Write(uint8_t high)
{
  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, high ? GPIO_PIN_SET : GPIO_PIN_RESET);
  g_la_pc13 = (high != 0U) ? 1U : 0U;
}

/**
  * @brief  控制板载 LED（PC13 低电平点亮，所以 on=1 要输出低电平）
  */
static void LED_Set(uint8_t on)
{
  PC13_Write(on ? 0 : 1);
}

#if (SIM_MODE == 1)


static void SimClockConfig(void)
{
  RCC->CR   = (1UL <<  0)   /* HSION  */
            | (1UL <<  1)   /* HSIRDY */
            | (1UL << 16)   /* HSEON  */
            | (1UL << 17)   /* HSERDY */
            | (1UL << 24)   /* PLLON  */
            | (1UL << 25);  /* PLLRDY */

  RCC->CFGR = (2UL <<  0)   /* SW    = PLL              */
            | (4UL <<  8)   /* PPRE1 = HCLK / 2 = 36MHz */
            | (1UL << 16)   /* PLLSRC= HSE              */
            | (7UL << 18);  /* PLLMUL= ×9 = 72MHz       */

  SystemCoreClock = 72000000U;
}

static void SimTransmit(uint32_t nbytes)
{
  uint32_t cycles;
  uint32_t load;
  uint32_t prev;
  uint32_t now;
  uint32_t elapsed = 0;
  uint32_t guard   = 0;

  /* 需要的时钟周期数 = 字节数 × 10 位 × 72 000 000 / 波特率 */
  cycles = (uint32_t)(((uint64_t)nbytes * 10ULL * 72000000ULL) / (uint64_t)BAUDRATE);

  load = SysTick->LOAD;     /* HAL_Init() 配成 71999（1ms） */
  prev = SysTick->VAL;      /* 向下递减的当前值 */

  while (elapsed < cycles)
  {
    now = SysTick->VAL;

    if (prev >= now)
    {
      elapsed += (prev - now);                 /* 没有翻卷 */
    }
    else
    {
      elapsed += prev + 1U + (load - now);     /* 中途翻卷，跨过 0 点 */
    }
    prev = now;

    if (++guard > cycles)
    {
      break;
    }
  }
}

#define UART_SEND(nbytes)   SimTransmit(nbytes)

#else  


#define UART_SEND(nbytes)   HAL_UART_Transmit(&huart1, g_msg, (nbytes), TX_TIMEOUT_MS)

#endif

/**
  * @brief  主函数
  */
int main(void)
{
  uint32_t led_tick  = 0;     /* 上一次翻转 LED 的时刻 */
  uint32_t send_tick = 0;     /* 上一次发送的时刻 */
  uint8_t  led_on    = 0;     /* LED 当前是否点亮 */

#if (SIM_MODE == 1)

  SimClockConfig();
#endif

  HAL_Init();                 /* 里面会初始化 SysTick = 1ms 中断 */

#if (SIM_MODE == 0)
  SystemClock_Config();       /* 真机：HSE + PLL 正常配置到 72MHz */
#endif
  MX_GPIO_Init();
  MX_USART1_UART_Init();

  if (HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1) != HAL_OK)
  {
    Error_Handler();
  }

  /* 上电先灭灯，计时基准取当前时刻 */
  LED_Set(0);
  led_tick  = g_ms_tick;
  send_tick = g_ms_tick;

  while (1)
  {
    uint32_t now = g_ms_tick;

    if (g_send_enable)
    {
      /* ---------- 1. LED 闪烁：每 LED_HALF_PERIOD_MS 翻转一次 ---------- */
      if ((uint32_t)(now - led_tick) >= LED_HALF_PERIOD_MS)
      {
        led_tick = now;
        led_on   = !led_on;
        LED_Set(led_on);
      }

      /* ---------- 2. 每隔 SEND_INTERVAL_MS 发一条数据 ---------- */
      if ((uint32_t)(now - send_tick) >= SEND_INTERVAL_MS)
      {
        send_tick = now;
        g_send_count++;

        if ((PULSE_EVERY_N_SENDS > 0) &&
            ((g_send_count % PULSE_EVERY_N_SENDS) == 0))
        {
          PC13_Write(0);   /* 脉冲开始：拉低 */
          UART_SEND(sizeof(g_msg) - 1);
          PC13_Write(1);   /* 脉冲结束：拉高 */

#if (PULSE_GAP_MS > 0)
          {   /* 补一段平直高电平，让逻辑分析仪上两个脉冲之间界限分明 */
            uint32_t gap_start = g_ms_tick;
            while ((uint32_t)(g_ms_tick - gap_start) < PULSE_GAP_MS)
            {
              /* 空等（阻塞）。只为了波形好看，实验里 1 秒无妨。 */
            }
          }
#endif

          LED_Set(0);        /* 脉冲用的是同一个 PC13，结束顺手灭灯 */
          led_on   = 0;
          led_tick = g_ms_tick;
        }
        else
        {
          /* 平常的发送：只发数据，不动 LED（LED 由上面第 1 步自己闪） */
          UART_SEND(sizeof(g_msg) - 1);
        }
      }
    }
    else
    {
      /* 暂停：LED 熄灭并保持，不再发送数据 */
      LED_Set(0);
      led_on       = 0;
      led_tick     = now;      /* 恢复发送时从当前时刻重新计时，避免灯卡在半亮 */
      g_send_count = 0;        /* 脉冲计数清零，恢复后重新排 */
    }
  }
}

/**
  * @brief  串口接收完成回调（HAL 库在 USART1_IRQHandler 中被调用）
  *         每收到 1 个字节进一次
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    if (g_rx_byte == '#')
    {
      g_send_enable = 0;          /* 暂停发送 */
    }
    else if (g_rx_byte == '*')
    {
      g_send_enable = 1;          /* 恢复发送 */
    }
    HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1);
  }
}

/**
  * @brief  串口错误回调（可选，便于调试）
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    /* 出错后重新开中断接收，避免串口"卡死" */
    HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1);
  }
}

#if (SIM_MODE == 0)
/**
  * @brief  系统时钟配置：HSE 8MHz -> PLL x9 -> 72MHz
  * @note   SIM_MODE = 1 时本函数不参与编译（改由 SimClockConfig() 直接写寄存器）
  */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}
#endif  /* SIM_MODE == 0 */

/**
  * @brief  USART1 初始化：115200 / 8 / 1 / 无校验
  * @note   USART1 中断的 NVIC 使能放在 HAL_UART_MspInit() 里，
  *         本工程对应的 stm32f1xx_hal_msp.c 已经无条件使能了它，
  *         所以不依赖任何编译宏。
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = BAUDRATE;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  GPIO 初始化：板载 LED (PC13)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();

  LED_Set(0);                                   /* 上电先灭灯（PC13 输出高） */
  GPIO_InitStruct.Pin   = LED_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);
}

/**
  * @brief  错误处理：LED 快闪提示
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);
    g_la_pc13 = (g_la_pc13 == 0U) ? 1U : 0U;   /* 镜像同步，供逻辑分析仪观察 */
    for (volatile uint32_t i = 0; i < 400000; i++) { }
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
