/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务二 (1)：用【串口接收中断】重做任务一 (2)
  *
  * ==== 本工程的功能（对应实验任务二①）====
  *   1. 通过 USART1 连续向上位机发送 "hello windows！"（115200, 8, 1, None）
  *   2. 上位机发 '#' → 暂停发送；发 '*' → 恢复发送
  *   3. 收发命令用【串口接收中断】实现（不是轮询）：
  *        初始化时 HAL_UART_Receive_IT() 开一次中断，
  *        之后每收到 1 字节，硬件自动进 USART1_IRQHandler → HAL 调用
  *        HAL_UART_RxCpltCallback() 回调我们处理；
  *        【回调里必须再次调用 HAL_UART_Receive_IT()】才能收下一个字节。
  *
  * ==== 与任务一 (2) 查询方式的区别 ====
  *   任务一(2)：主循环里用 HAL_UART_Receive(..., 1ms) 反复"问"串口有没有数据
  *   本工程  ：CPU 完全不用管串口，来了数据硬件自动打断主循环去处理
  *   —— 效率更高、响应更实时。
  *
  * ==== LED 现象（板载 PC13，低电平点亮）====
  *   发送中 ：LED 每 500ms 翻转一次（0.5s 亮 / 0.5s 灭），肉眼清晰可见
  *   暂停时 ：LED 熄灭（保持）
  *
  * ==== 【任务三】Keil 软件仿真 · 逻辑分析仪怎么用这个工程 ====
  *   前提认知（实测结论，别再去找 USART1_TX 了）：
  *     Keil 的 Cortex-M 通用仿真器【只有内核模型，没有 STM32 外设模型】。
  *     所以逻辑分析仪里输入 USART1_TX 或 PORTA.9 都会弹 "Unknown Signal"，
  *     仿真器不会按 BRR 的波特率在 PA9 上画出真正的串口波形。
  *
  *   那任务三怎么办？两条路，都能写进实验报告：
  *
  *   路线 1（本文件已实现）——量"发送区间"，反推波特率：
  *     a. 逻辑分析仪 Setup → 点右上角"新建"图标 → 信号名填   g_la_pc13
  *        （g_la_pc13 是本文件里的全局变量，它镜像 PC13 的电平；0=低电平/亮，1=高电平/灭。
  *          注意不能填 GPIOC->ODR & 0x2000，逻辑分析仪只认变量名，不认表达式）
  *     b. Display Type 从 Analog 改成 Bit
  *     c. F5 运行几秒后停下，你会看到"一个窄低脉冲 + 一段平直高电平"
  *     d. 量窄低脉冲的宽度 T（就是 HAL_UART_Transmit() 的耗时）
  *     e. 换算：本帧 18 字节 = 180 位，每位理想值 = T/180，
  *             反推波特率 = 180/T，与 BRR 算出的 115200 对照
  *     注意：仿真器跑指令比真机快得多，T 会远小于真机的 1.6ms，
  *           所以这是"时序关系验证"，不是"真机波特率实测"。
  *
  *   路线 2（推荐当主要证据）——寄存器验证法，数值精确：
  *     进入仿真后 Peripherals → System Viewer → USART1，读 BRR：
  *       USARTDIV = 72 000 000 / (16 × 115200) = 39.0625
  *       BRR = (39 << 4) | 1 = 0x271
  *       → 实际波特率 115200，误差 0%
  *     在 Watch 窗口也能直接看：USART1->BRR
  *
  *   不想让它干扰正常实验：把下面 PULSE_EVERY_N_SENDS 改成 0 即可关闭。
  *
  * ==== 本文件的重要设计说明（为什么这么写）====
  *   1. 【不依赖任何编译宏开关】
  *      以前"当前是哪个任务"靠 project_config.h 里的宏判断，
  *      一旦工程选项里的宏没配对，中断服务函数就会被静默编译掉，
  *      表现为"编译 0 错误，但串口中断完全不工作"，极难排查。
  *      现在本文件的配置全部写死在这里，拿去任何工程都能直接用。
  *
  *   2. 【LED 用非阻塞方式闪烁】
  *      不再用 HAL_Delay() 阻塞主循环。主循环每 1ms 转一圈，
  *      用系统滴答计数 g_ms_tick 判断该不该翻转 LED，
  *      这样"串口发送"和"LED 闪烁"互不干扰，闪灯节奏精确稳定：
  *      串口可以发得很快，LED 照样稳稳地 0.5s 亮 / 0.5s 灭。
  ******************************************************************************
  */
#include "project_config.h"   /* 只为了拿 BAUDRATE（波特率），其余全部在本文件写死 */
#include "main.h"

/* ======================== 本工程的配置（写死，不靠宏） ======================== */

/* ============ 【任务三 仿真模式开关】 ============
 * 0 = 真机模式（默认）。烧到板子上做任务二①时必须是 0。
 * 1 = 仿真模式。任务三用 Keil 软件仿真 + 逻辑分析仪时才改成 1。
 *
 * 为什么需要这个开关：
 *   Keil 的 Cortex-M 仿真器【没有 STM32 外设模型】，这些"就绪标志"永远不会被置位：
 *     - RCC 的 HSERDY / PLLRDY  → 程序会卡死在 SystemClock_Config() 的等待循环里
 *       （你会看到 PC 停在 stm32f1xx_hal_rcc.c 的 while (__HAL_RCC_GET_FLAG(...HSERDY)...) ）
 *     - USART 的 TXE / TC       → HAL_UART_Transmit() 只能等到 100ms 超时才返回
 *
 *   打开 SIM_MODE 后：
 *     1) 直接写 RCC 寄存器，等价于"告诉 HAL 时钟已经就绪"，跳过所有等待循环；
 *     2) 发送时长改为按 115200/8N1 的【理论位时间】用 SysTick 逐周期计数器产生
 *        （18 字节 × 10 位 × 8.6806µs = 1.5624ms），
 *        这样逻辑分析仪上量到的脉冲宽度就等于"一条报文的发送时长"。
 */
#define SIM_MODE   1

/* 两次发送之间的间隔(ms)。
 * 500ms → 串口每秒 2 条，LED 0.5s 亮 / 0.5s 灭，看得清清楚楚。
 * 想让它更快就改小（例如 100），想更慢就改大（例如 1000）。 */
#define SEND_INTERVAL_MS     500

/* LED 闪烁：每亮/灭持续多少毫秒（250 → 亮 0.25s + 灭 0.25s，一秒闪两次） */
#define LED_HALF_PERIOD_MS   250

/* 串口发送超时(ms)。一帧 "hello windows！\r\n" 共 18 字节，
 * 115200bps 下只需要约 1.6ms，给 100ms 余量足够，绝不会真超时。 */
#define TX_TIMEOUT_MS        100

/* ============ 【任务三 仿真测量专用】发送区间标注 ============
 * 作用：在 PC13 上产生一个"脉冲"，脉冲宽度 = 一次 HAL_UART_Transmit() 的耗时。
 *       观测点在全局变量 g_la_pc13 上（它镜像了 PC13 的电平），
 *       在 Keil 逻辑分析仪里添加信号名 g_la_pc13 就能画出来。
 *
 * 为什么要这么做：Keil 的 Cortex-M 仿真器【没有 STM32 外设行为模型】，
 *       所以逻辑分析仪里写 USART1_TX / PORTA.9 / GPIOC->ODR & 0x2000
 *       都会报 "Unknown Signal"，仿真器不会按波特率在 PA9 上画出真正的串口波形。
 *       我们能测的是"CPU 为这次发送花了多少时间"（见文件末尾说明）。
 *
 * 取值：每 PULSE_EVERY_N_SENDS 次发送才输出一个脉冲。
 *       500ms 发一次，每 50 次标注一次 → 每 25 秒一个脉冲，
 *       再配合 1 秒的 PULSE_GAP_MS，波形稀疏、好缩放、好量。
 *       不想被它影响就改成 0（等于关闭本功能）。 */
#define PULSE_EVERY_N_SENDS  50

/* 一个脉冲结束后，再补 1 秒"平直高电平"，让波形之间留出可辨认的间隔。
 * 这段时间内不发送数据；不想留间隔就改成 0。 */
#define PULSE_GAP_MS         1000

/* ============================ 全局变量 ============================ */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;      /* 本任务不用 DMA，仅为兼容 main.h 里的 extern */

uint8_t  g_msg[]       = "hello windows！\r\n";   /* 要发送的数据 */
uint8_t  g_rx_byte     = 0;             /* 中断接收缓冲，一次 1 字节 */
uint8_t  g_send_enable = 1;             /* 1 = 发送中；0 = 已暂停 */
uint32_t g_send_count  = 0;             /* 已发送条数，用于任务三的脉冲标注 */

/* ===== 【任务三 仿真观测点】=====
 * Keil 的 Logic Analyzer 只能采样"程序里的变量"，不认 `GPIOC->ODR & 0x2000`
 * 这类表达式（会弹 Unknown Signal）。所以这里放一个变量，专门镜像 PC13 的
 * 当前电平，在逻辑分析仪里直接添加信号名 g_la_pc13 即可。
 * 取值范围只有 0 / 1：1 = PC13 输出高电平（灯灭），0 = 低电平（灯亮）。 */
volatile uint32_t g_la_pc13 = 0;

/* 函数声明 */
#if (SIM_MODE == 0)
static void SystemClock_Config(void);
#endif
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void LED_Set(uint8_t on);
static void PC13_Write(uint8_t high);

/**
  * @brief  写 PC13 电平，并把同一个电平镜像到 g_la_pc13
  * @param  high: 1 = 输出高电平（LED 灭），0 = 输出低电平（LED 亮）
  * @note   所有对 PC13 的操作都必须走这个函数，
  *         否则逻辑分析仪看到的镜像就会和真实引脚不一致。
  */
static void PC13_Write(uint8_t high)
{
  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, high ? GPIO_PIN_SET : GPIO_PIN_RESET);
  g_la_pc13 = (high != 0U) ? 1U : 0U;
}

/**
  * @brief  控制板载 LED（PC13 低电平点亮，所以 on=1 要输出低电平）
  */
static void LED_Set(uint8_t on)
{
  PC13_Write(on ? 0 : 1);
}

#if (SIM_MODE == 1)
/* ==================================================================
 *            以下两个函数【只在 SIM_MODE = 1 时存在】
 * ================================================================== */

/**
  * @brief  仿真专用：直接写 RCC 寄存器，跳过所有"等就绪标志"的死循环
  * @note   配出来的结果是：SYSCLK = HSE 8MHz × PLL9 = 72MHz
  *                        HCLK = 72MHz，APB1(PPRE1) = 36MHz，APB2(PPRE2) = 72MHz
  *         因为寄存器是"真值"，所以随后 HAL_RCC_GetPCLK2Freq() 会返回 72MHz，
  *         HAL_UART_Init() 算出的 BRR 就仍然是 0x271 —— 和真机完全一致。
  */
static void SimClockConfig(void)
{
  RCC->CR   = (1UL <<  0)   /* HSION  */
            | (1UL <<  1)   /* HSIRDY */
            | (1UL << 16)   /* HSEON  */
            | (1UL << 17)   /* HSERDY */
            | (1UL << 24)   /* PLLON  */
            | (1UL << 25);  /* PLLRDY */

  RCC->CFGR = (2UL <<  0)   /* SW    = PLL              */
            | (4UL <<  8)   /* PPRE1 = HCLK / 2 = 36MHz */
            | (1UL << 16)   /* PLLSRC= HSE              */
            | (7UL << 18);  /* PLLMUL= ×9 = 72MHz       */

  SystemCoreClock = 72000000U;
}

/**
  * @brief  仿真专用：走完"一条报文的发送时长"
  * @param  nbytes: 本条报文的字节数
  * @note   1 位 = 1 / 波特率 秒。115200bps 时 1 位 = 8.6806µs，
  *         1 字节 = 10 位（起始 + 8 数据 + 停止），
  *         18 字节 = 180 位 = 1562.5µs = 112500 个 72MHz 时钟周期。
  *
  *         用什么计时：SysTick 的 VAL 寄存器（0xE000E018，内核自带）。
  *         它是【一定会被仿真器实现】的内核外设（中继中断都靠它），
  *         而且是 72MHz 逐周期递减的硬件计数器，分辨率 13.89ns，
  *         比 HAL_GetTick() 的 1ms 分辨率精细得多。
  *
  *         注意：**不要用 DWT->CYCCNT**。Cortex-M3 的 DWT 属于调试/跟踪单元
  *         （地址 0xE0001004），Keil 的仿真器没有为它建立存储器映射，
  *         读它会报 `error 65: access violation at 0xE0001004 : no 'read' permission`，
  *         而且每读一次就打一行日志，程序会被拖到几乎跑不动。
  */
static void SimTransmit(uint32_t nbytes)
{
  uint32_t cycles;
  uint32_t load;
  uint32_t prev;
  uint32_t now;
  uint32_t elapsed = 0;
  uint32_t guard   = 0;

  /* 需要的时钟周期数 = 字节数 × 10 位 × 72 000 000 / 波特率 */
  cycles = (uint32_t)(((uint64_t)nbytes * 10ULL * 72000000ULL) / (uint64_t)BAUDRATE);

  load = SysTick->LOAD;     /* HAL_Init() 配成 71999（1ms） */
  prev = SysTick->VAL;      /* 向下递减的当前值 */

  while (elapsed < cycles)
  {
    now = SysTick->VAL;

    if (prev >= now)
    {
      elapsed += (prev - now);                 /* 没有翻卷 */
    }
    else
    {
      elapsed += prev + 1U + (load - now);     /* 中途翻卷，跨过 0 点 */
    }
    prev = now;

    /* 保险：万一这个仿真环境里 SysTick 也不走，别死等 */
    if (++guard > cycles)
    {
      break;
    }
  }
}

/* 发送动作：仿真模式下不再调 HAL_UART_Transmit()，而是走上面的定时函数 */
#define UART_SEND(nbytes)   SimTransmit(nbytes)

#else  /* SIM_MODE == 0：真机模式，正常调用 HAL 库发送 */

/* 发送动作：真机上就是老老实实调用 HAL 库 */
#define UART_SEND(nbytes)   HAL_UART_Transmit(&huart1, g_msg, (nbytes), TX_TIMEOUT_MS)

#endif

/**
  * @brief  主函数
  */
int main(void)
{
  uint32_t led_tick  = 0;     /* 上一次翻转 LED 的时刻 */
  uint32_t send_tick = 0;     /* 上一次发送的时刻 */
  uint8_t  led_on    = 0;     /* LED 当前是否点亮 */

#if (SIM_MODE == 1)
  /* 【顺序很重要】SimClockConfig() 必须放在 HAL_Init() 之前。
   * 因为 HAL_Init() 里会按 HAL_RCC_GetHCLKFreq() 算 SysTick 的 1ms 重载值，
   * 而 HAL_RCC_GetHCLKFreq() 读的就是 RCC->CFGR —— 先写寄存器，72MHz 才能生效，
   * 否则 SysTick 会按 8MHz 算（重载值 7999），g_ms_tick 会快 9 倍，
   * 500ms 的发送间隔实际只有 55ms，仿真里看起来就是在狂发。 */
  SimClockConfig();
#endif

  HAL_Init();                 /* 里面会初始化 SysTick = 1ms 中断 */

#if (SIM_MODE == 0)
  SystemClock_Config();       /* 真机：HSE + PLL 正常配置到 72MHz */
#endif
  MX_GPIO_Init();
  MX_USART1_UART_Init();

  /* 【关键】开启第一次中断接收；之后每次进回调都要重新开一次 */
  if (HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1) != HAL_OK)
  {
    Error_Handler();
  }

  /* 上电先灭灯，计时基准取当前时刻 */
  LED_Set(0);
  led_tick  = g_ms_tick;
  send_tick = g_ms_tick;

  while (1)
  {
    uint32_t now = g_ms_tick;

    if (g_send_enable)
    {
      /* ---------- 1. LED 闪烁：每 LED_HALF_PERIOD_MS 翻转一次 ---------- */
      if ((uint32_t)(now - led_tick) >= LED_HALF_PERIOD_MS)
      {
        led_tick = now;
        led_on   = !led_on;
        LED_Set(led_on);
      }

      /* ---------- 2. 每隔 SEND_INTERVAL_MS 发一条数据 ---------- */
      if ((uint32_t)(now - send_tick) >= SEND_INTERVAL_MS)
      {
        send_tick = now;
        g_send_count++;

        /* 每 PULSE_EVERY_N_SENDS 次发送，在 PC13 上标一个"发送区间"脉冲。
         * 段1（低电平）：脉冲宽度 = HAL_UART_Transmit() 的耗时 ← 任务三要量的就是它
         * 段2（高电平）：补 PULSE_GAP_MS 的平直段，方便在逻辑分析仪里分隔两次脉冲
         * 不需要任务三测量时，把 PULSE_EVERY_N_SENDS 改成 0 即可完全关闭。 */
        if ((PULSE_EVERY_N_SENDS > 0) &&
            ((g_send_count % PULSE_EVERY_N_SENDS) == 0))
        {
          PC13_Write(0);   /* 脉冲开始：拉低 */
          UART_SEND(sizeof(g_msg) - 1);
          PC13_Write(1);   /* 脉冲结束：拉高 */

#if (PULSE_GAP_MS > 0)
          {   /* 补一段平直高电平，让逻辑分析仪上两个脉冲之间界限分明 */
            uint32_t gap_start = g_ms_tick;
            while ((uint32_t)(g_ms_tick - gap_start) < PULSE_GAP_MS)
            {
              /* 空等（阻塞）。只为了波形好看，实验里 1 秒无妨。 */
            }
          }
#endif

          LED_Set(0);        /* 脉冲用的是同一个 PC13，结束顺手灭灯 */
          led_on   = 0;
          led_tick = g_ms_tick;
        }
        else
        {
          /* 平常的发送：只发数据，不动 LED（LED 由上面第 1 步自己闪） */
          UART_SEND(sizeof(g_msg) - 1);
        }
      }
    }
    else
    {
      /* 暂停：LED 熄灭并保持，不再发送数据 */
      LED_Set(0);
      led_on       = 0;
      led_tick     = now;      /* 恢复发送时从当前时刻重新计时，避免灯卡在半亮 */
      g_send_count = 0;        /* 脉冲计数清零，恢复后重新排 */
    }
  }
}

/**
  * @brief  串口接收完成回调（HAL 库在 USART1_IRQHandler 中被调用）
  *         每收到 1 个字节进一次
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    if (g_rx_byte == '#')
    {
      g_send_enable = 0;          /* 暂停发送 */
    }
    else if (g_rx_byte == '*')
    {
      g_send_enable = 1;          /* 恢复发送 */
    }
    /* 其他字符忽略（比如串口助手回车换行产生的 \r\n） */

    /* 【必须】重新开启中断接收，否则只能收到第一个字节 */
    HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1);
  }
}

/**
  * @brief  串口错误回调（可选，便于调试）
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    /* 出错后重新开中断接收，避免串口"卡死" */
    HAL_UART_Receive_IT(&huart1, &g_rx_byte, 1);
  }
}

#if (SIM_MODE == 0)
/**
  * @brief  系统时钟配置：HSE 8MHz -> PLL x9 -> 72MHz
  * @note   SIM_MODE = 1 时本函数不参与编译（改由 SimClockConfig() 直接写寄存器）
  */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}
#endif  /* SIM_MODE == 0 */

/**
  * @brief  USART1 初始化：115200 / 8 / 1 / 无校验
  * @note   USART1 中断的 NVIC 使能放在 HAL_UART_MspInit() 里，
  *         本工程对应的 stm32f1xx_hal_msp.c 已经无条件使能了它，
  *         所以不依赖任何编译宏。
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = BAUDRATE;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  GPIO 初始化：板载 LED (PC13)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();

  LED_Set(0);                                   /* 上电先灭灯（PC13 输出高） */
  GPIO_InitStruct.Pin   = LED_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);
}

/**
  * @brief  错误处理：LED 快闪提示
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);
    g_la_pc13 = (g_la_pc13 == 0U) ? 1U : 0U;   /* 镜像同步，供逻辑分析仪观察 */
    for (volatile uint32_t i = 0; i < 400000; i++) { }
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
