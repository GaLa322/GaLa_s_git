/**
  ******************************************************************************
  * @file    main.c
  
  ******************************************************************************
  */
#include "project_config.h"
#include "main.h"

/* ============================ 全局变量 ============================ */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;

uint8_t g_msg[] = "hello windows！\r\n";

/* ============================ 函数声明 ============================ */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);

/**
  * @brief  主函数
  */
int main(void)
{
  /* 1. 复位所有外设，初始化 Flash 接口和 SysTick */
  HAL_Init();

  /* 2. 配置系统时钟：HSE 8MHz -> PLL x9 -> SYSCLK 72MHz */
  SystemClock_Config();

  /* 3. 初始化 GPIO 与 USART1 */
  MX_GPIO_Init();
  MX_USART1_UART_Init();

  /* 4. 循环发送 */
  while (1)
  {
    /* 阻塞式发送：HAL 库内部逐字节等待 TXE 标志，发完一帧才返回 */
    HAL_UART_Transmit(&huart1, g_msg, sizeof(g_msg) - 1, HAL_MAX_DELAY);

    /* 翻转板载 LED，方便肉眼确认程序在跑 */
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);

#if (SEND_DELAY_MS > 0)
    HAL_Delay(SEND_DELAY_MS);
#endif
  }
}

/**
  * @brief  系统时钟配置
  *         HSE(8MHz) -> PLLMUL9 -> SYSCLK = 72MHz
  *         AHB = 72MHz, APB1 = 36MHz, APB2 = 72MHz
  *         注意：USART1 挂在 APB2 上，所以 PCLK2 = 72MHz
  */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /* 打开 HSE 并配置 PLL */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* 切换系统时钟到 PLL，并设置各总线分频 */
  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;   /* HCLK  = 72MHz */
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;     /* PCLK1 = 36MHz */
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;     /* PCLK2 = 72MHz */
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  USART1 初始化
  *         115200 bps / 8 数据位 / 1 停止位 / 无校验 / 无硬件流控
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = 115200;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  GPIO 初始化：只用板载 LED (PC13)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();

  /* PC13 推挽输出，初始灭（高电平灭） */
  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_SET);
  GPIO_InitStruct.Pin   = LED_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);
}

/**
  * @brief  错误处理：点亮 LED 并死循环
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);
    for (volatile uint32_t i = 0; i < 400000; i++) { }
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
