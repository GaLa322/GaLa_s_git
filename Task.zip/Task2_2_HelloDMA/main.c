/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务二 (2)：USART1 采用【DMA 方式】以 115200bps 或更高速率连续发送
  *
  * DMA 原理简述：
  *   CPU 只要把"数据在哪、要发多少字节"告诉 DMA 控制器并启动一次，
  *   之后每发一个字节由 DMA 自动把内存数据搬到 USART1->DR 寄存器，
  *   CPU 全程不参与搬运，可以去干别的事（本例里去翻转 LED）。
  *   发送完成时 DMA 产生中断，HAL 库调用 HAL_UART_TxCpltCallback() 通知我们。
  *
  * 本工程使用的通道（STM32F103 的固定映射，不能随便改）：
  *   USART1_TX -> DMA1_Channel4
  *   USART1_RX -> DMA1_Channel5（本例只做发送）
  ******************************************************************************
  */
#include "project_config.h"
#include "main.h"

/* 1 = 用 DMA 连续发送；0 = 用阻塞式发送，方便做对比实验 */
#define USE_DMA_TX        1

/* ============================ 全局变量 ============================ */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;

uint8_t  g_msg[]        = "hello windows！\r\n";
uint8_t  g_tx_busy      = 0;    /* 1 = DMA 正在发送 */
uint32_t g_tx_ok_count  = 0;    /* 成功发送的帧数 */
uint32_t g_tx_err_count = 0;    /* 发送失败次数 */

/* ============================ 函数声明 ============================ */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);

/**
  * @brief  主函数
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART1_UART_Init();

  while (1)
  {
    /* 上一帧发完了才启动下一帧，避免 DMA 重入 */
    if (g_tx_busy == 0)
    {
#if (USE_DMA_TX == 1)
      /* DMA 方式：函数立刻返回，数据由 DMA 在后台搬运 */
      if (HAL_UART_Transmit_DMA(&huart1, g_msg, sizeof(g_msg) - 1) == HAL_OK)
      {
        g_tx_busy = 1;
      }
      else
      {
        g_tx_err_count++;
      }
#else
      /* 阻塞方式（对比用）：CPU 死等发完 */
      HAL_UART_Transmit(&huart1, g_msg, sizeof(g_msg) - 1, HAL_MAX_DELAY);
      g_tx_ok_count++;
#endif
    }

    /* DMA 在后台发数据，CPU 有空干别的事：这里翻转 LED */
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);

#if (SEND_DELAY_MS > 0)
    HAL_Delay(SEND_DELAY_MS);
#endif
  }
}

/**
  * @brief  DMA 发送完成回调
  */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    g_tx_busy = 0;
    g_tx_ok_count++;
  }
}

/**
  * @brief  串口错误回调
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    g_tx_busy = 0;
    g_tx_err_count++;
  }
}

/**
  * @brief  系统时钟配置：HSE 8MHz -> PLL x9 -> 72MHz
  */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  USART1 初始化：BAUDRATE / 8 / 1 / 无校验
  *         DMA 相关的 gpio/通道配置在 HAL_UART_MspInit() 里完成
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = BAUDRATE;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief  GPIO 初始化：板载 LED (PC13)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();

  HAL_GPIO_WritePin(LED_GPIO_PORT, LED_PIN, GPIO_PIN_SET);
  GPIO_InitStruct.Pin   = LED_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);
}

/**
  * @brief  错误处理
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_PIN);
    for (volatile uint32_t i = 0; i < 400000; i++) { }
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
